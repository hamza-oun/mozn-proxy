const ORIGIN = 'https://mozn-proxy.vercel.app';
const BASE = 'https://api.4shadow.io/v1';

export default async function handler(req, res) {
  const apiKey = process.env.API_KEY || process.env.FORESHADOW_API_KEY;
  if (!apiKey) return res.status(403).json({ error: "An API Key is required to make this request" });

  try {
    const r = await fetch(`${BASE}/parameters`, {
      method: 'GET',
      headers: { 'Accept':'application/json', 'X-Api-Key': apiKey, 'Origin': ORIGIN }
    });
    const txt = await r.text();
    res.status(r.status).setHeader('Content-Type','application/json').send(txt);
  } catch (e) {
    res.status(500).json({ error:'Proxy request failed', details:String(e?.message||e) });
  }
}
