# MOZN Foreshadow Proxy (hardcoded Origin)

This version forces the `Origin` header to `https://mozn-proxy.vercel.app` to satisfy 4Shadow domain allow-listing.

## Endpoints
- GET `/api/diag`
- GET `/api/parameters`  (also `/parameters.json`)
- GET `/api/point?lat=..&lon=..` (also `/point.json?...`)
- POST `/api/forecast`    (also `/forecast.json`)

## Setup on Vercel
Add env var:
- `API_KEY` = your 4Shadow key

Deploy, then test:
- `curl -s https://mozn-proxy.vercel.app/api/diag`
- `curl -s https://mozn-proxy.vercel.app/api/parameters`
- `curl -s "https://mozn-proxy.vercel.app/api/point?lat=32.768&lon=22.6396"`
- `curl -i -s -X POST "https://mozn-proxy.vercel.app/api/forecast" -H "Content-Type: application/json" --data-binary "{"model":"GFS","lat":32.768,"lon":22.6396,"params":["t2m","prate"],"hours":72}"`
