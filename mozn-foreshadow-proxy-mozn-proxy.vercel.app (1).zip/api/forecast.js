const ORIGIN = 'https://mozn-proxy.vercel.app';
const BASE = 'https://api.4shadow.io/v1';

export default async function handler(req, res) {
  const apiKey = process.env.API_KEY || process.env.FORESHADOW_API_KEY;
  if (!apiKey) return res.status(403).json({ error: "An API Key is required to make this request" });
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    let bodyObj = req.body;
    if (!bodyObj || typeof bodyObj !== 'object') {
      const chunks = [];
      for await (const c of req) chunks.push(c);
      const raw = Buffer.concat(chunks).toString('utf8');
      if (raw) { try { bodyObj = JSON.parse(raw); } catch {} }
    }
    const r = await fetch(`${BASE}/forecast`, {
      method: 'POST',
      headers: {
        'Content-Type':'application/json',
        'Accept':'application/json',
        'X-Api-Key': apiKey,
        'Origin': ORIGIN
      },
      body: JSON.stringify(bodyObj || {})
    });
    const txt = await r.text();
    res.status(r.status).setHeader('Content-Type','application/json').send(txt);
  } catch (e) {
    res.status(500).json({ error:'Proxy request failed', details:String(e?.message||e) });
  }
}
