const ORIGIN = 'https://mozn-proxy.vercel.app';
const BASE = 'https://api.4shadow.io/v1';

export default async function handler(req, res) {
  const apiKey = process.env.API_KEY || process.env.FORESHADOW_API_KEY;
  if (!apiKey) return res.status(403).json({ error: "An API Key is required to make this request" });

  try {
    const incoming = new URL(req.url, ORIGIN);
    const lat = incoming.searchParams.get('lat');
    const lon = incoming.searchParams.get('lon');

    const u = new URL(`${BASE}/point`);
    if (lat) u.searchParams.set('lat', lat);
    if (lon) u.searchParams.set('lon', lon);
    u.searchParams.set('api-key', apiKey);

    const r = await fetch(u.toString(), { headers: { 'Accept':'application/json', 'Origin': ORIGIN } });
    const txt = await r.text();
    res.status(r.status).setHeader('Content-Type','application/json').send(txt);
  } catch (e) {
    res.status(500).json({ error:'Proxy request failed', details:String(e?.message||e) });
  }
}
