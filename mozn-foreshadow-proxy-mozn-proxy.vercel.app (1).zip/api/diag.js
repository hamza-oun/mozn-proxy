export default function handler(req, res) {
  res.json({
    hasAPI_KEY: !!process.env.API_KEY,
    hasFORESHADOW_API_KEY: !!process.env.FORESHADOW_API_KEY,
    originForced: "https://mozn-proxy.vercel.app",
    route: "/api/diag"
  });
}
